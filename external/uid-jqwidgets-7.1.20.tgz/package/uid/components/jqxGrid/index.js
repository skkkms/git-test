import jqxGrid from '../../../jqwidgets-vue/vue_jqxgrid.vue'

jqxGrid.install = function install(Vue) {
  Vue.component('jqx-grid', jqxGrid)
}

export default jqxGrid
