import jqxTree from '../../../jqwidgets-vue/vue_jqxtree.vue'

jqxTree.install = function install(Vue) {
  Vue.component('jqx-tree', jqxTree)
}

export default jqxTree
