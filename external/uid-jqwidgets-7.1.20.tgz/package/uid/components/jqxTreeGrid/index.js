import jqxTreeGrid from '../../../jqwidgets-vue/vue_jqxtreegrid.vue'

jqxTreeGrid.install = function install(Vue) {
  Vue.component('jqx-tree-grid', jqxTreeGrid)
}

export default jqxTreeGrid
