import * as components from './components'

const UidJqwidgets = {
  install (Vue, options) {
    Object.values(components).forEach(function (component) {
      Vue.use(component)
    })
  }
}

export default UidJqwidgets
